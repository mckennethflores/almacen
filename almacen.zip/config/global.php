<?php 

define("DB_ENCODE","utf8");
define("PRO_NOMBRE","NOE");
define("DB_HOST","localhost");
define("DB_NAME", "almacendb");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");

define("ROL_ADMINISTRADOR",1);
define("ROL_VENDEDOR",2);


const URL = "http://localhost/almacen";

const SPD = ".";
const SPM = ",";
const MMONEY = "S/";

	//Datos envio de correo
	const EMAIL = "amconfecciones@gmail.com";
	const NOMBRE_REMITENTE = "Amconfecciones";
	const EMAIL_REMITENTE = "no-reply@amconfecciones.com";
	const NOMBRE_EMPRESA = "am_confecciones";
	const ADDRESS = "Lima";
	const ADDRESS2 = "Lima";
	const RUC = "00000000000";
	const NOMBRE_EMPRESA_SLUG = "A-M";
	const WEB_EMPRESA = "www.amconfecciones.com";
/* 	+1 (954) 630-5627 */

	const EMAIL_RECIBE = "amconfecciones@gmail.com";

	const CODIGO = "51";
	const CELULAR1 = "";
	const CELULAR2 = "";
	const PAIS = "+51";

?>